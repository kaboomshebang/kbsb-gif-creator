const imgBtn = document.getElementById('images-btn');
const gifBtn = document.getElementById('create-btn');
const images = []; // array of image objects

// create the images array
imgBtn.addEventListener('click', (e) => {
	e.preventDefault();

	//! add logic to check if the images are the same size
	//! warn if not
	const files = document.querySelector('#files');
	const cnt = document.querySelector('#img-container');
	for (f of files.files) {
		const figure = document.createElement('figure');
		figure.classList.add('gif-frame');
		const img = document.createElement('img');
		img.src = URL.createObjectURL(f);
		const caption = document.createElement('figcaption');
		// wait until image has loaded // otherwise size is 0
		img.onload = () => {
			caption.innerText = `${img.naturalWidth}px X ${img.naturalHeight}px`;
		};
		figure.appendChild(img);
		figure.appendChild(caption);
		cnt.appendChild(figure);
		images.push(img);
	}
});

// create the GIF image
gifBtn.addEventListener('click', (e) => {
	e.preventDefault(); // make sure the button doesn't have an action

	const width = document.querySelector('#width');
	const height = document.querySelector('#height');
	const duration = document.querySelector('#duration');
	const quality = document.querySelector('#quality');

	// container for the outputted GIF
	const outputCnt = document.querySelector('#output-container');

	// https://github.com/yahoo/gifshot#options
	gifshot.createGIF(
		{
			gifWidth: width.value,
			gifHeight: height.value,
			images: images,
			frameDuration: duration.value, // The amount of time (10 = 1s) to stay on each frame
			sampleInterval: quality.value, // quality setting, lower is better quality // lowest is 1
			numWorkers: 2, // number of web workers for processing frames
		},
		(obj) => {
			if (!obj.error) {
				const image = obj.image,
					animatedImage = document.createElement('img');
				animatedImage.src = image;
				outputCnt.appendChild(animatedImage);
			}
		}
	);
});
